<?php $__env->startSection('content'); ?>
<main>
    <div id="admin-form-list">
        <div class="container">
            <div class="row">
                <form method="post" action="<?php echo e(url('/team/'.$peserta->NIM)); ?>" class="col s12">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PUT')); ?>

                    <div class="row">
                        <div class="input-field col s12">
                            <input name="nama" id="nama" type="text" class="validate"">
                            <label for="nama">Nama Lengkap</label>
                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s12">
                            <input name="NIM" id="NIM" type="text" class="validate">
                            <label for="NIM">Isi</label>
                        </div>
                    </div>
                    <div class="row" style="">
                        <div class="input-field col s12"> <i class="material-icons prefix">dns</i>
                            <select id="fak_agg1">
                              <option value="" disabled selected>Fakultas</option>
                              <?php foreach($fakultas as $list_fak): ?>
                                <option value="<?php echo e($list_fak->id_fak); ?>"><?php echo e($list_fak->fakultas); ?></option>
                              <?php endforeach; ?>
                            </select>
                            <label>Fakultas</label>
                        </div>
                    </div>
                    <div class="row" style="">
                        <div class="input-field col s12"> <i class="material-icons prefix">dns</i>
                            <select name="prodi" id="prodi_agg1">
                              <option value="" disabled selected>Program Studi</option>
                            </select>
                            <label>Program Studi</label>
                        </div>
                    </div>
                    <div class="row center-align">
                        <button class="btn-large-blue waves-effect waves-light" type="submit" name="action">SIMPAN</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/getprodi.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
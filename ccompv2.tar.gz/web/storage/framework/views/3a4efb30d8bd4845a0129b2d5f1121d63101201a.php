<?php $__env->startSection('content'); ?>
<main>
<!-- <div id="debugger">hehehehe</div> -->
    <div id="form-satu">
        <div class="container">
            <div class="row z-depth-2">
                <form method="post" action="<?php echo e(url('/team')); ?>" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="col s12 m12 l12">
                        <div class="row">
                            <div class="input-field col s12"> <i class="material-icons prefix">perm_identity</i>
                                <input name="ketua" type="text" id="ketua" class="validate" />
                                <label for="ketua">Nama</label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="input-field col s12"> <i class="material-icons prefix">contacts</i>
                                <input name="nim_ketua" type="text" id="nim_ketua" class="validate" />
                                <label for="nim_ketua">NIM</label>
                            </div>
                        </div>
                        <div class="row" style="">
                            <div class="input-field col s12"> <i class="material-icons prefix">dns</i>
                                <select id="fak_ketua">
                                  <option value="" disabled selected>Fakultas</option>
                                  <?php foreach($fakultas as $list_fak_ketua): ?>
                                    <option value="<?php echo e($list_fak_ketua->id_fak); ?>"><?php echo e($list_fak_ketua->fakultas); ?></option>
                                  <?php endforeach; ?>
                                </select>
                                <label>Fakultas</label>
                            </div>
                        </div>
                        <div class="row" style="">
                            <div class="input-field col s12"> <i class="material-icons prefix">dns</i>
                                <select name="prodi_ketua" id="prodi_ketua">
                                  <option value="" disabled selected>Program Studi</option>
                                </select>
                                <label>Program Studi</label>
                            </div>
                        </div>
                        <div class="headform col s12">
                            <h6 class="judul"><b>KARTU TANDA MAHASISWA</b></h6>
                        </div>
                        <div class="headform col s12"><br></div>
                        <div class="row">
                            <div class="file-field input-field">
                                <div class="btn btn-blue">
                                    <span>File</span>
                                    <input name="ktm_ketua" type="file" multiple>
                                </div>
                                <div class="file-path-wrapper">
                                    <input class="file-path validate" type="text" placeholder="KTM Ketua Tim">
                                </div>
                            </div>
                        </div>
                        <div class="row center-align">
                            <button class="btn-large-blue waves-effect waves-light" type="submit" name="action">SIMPAN</button>
                        </div>

                    </div>
                </form>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(url('/js/getprodi.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
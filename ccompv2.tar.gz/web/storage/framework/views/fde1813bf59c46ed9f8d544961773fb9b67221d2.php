<!-- navbar dekstop -->
<div class="navbar-fixed">
    <nav role="navigation">
        <div class="nav-wrapper container">
            <a id="logo-container" href="<?php echo e(url('/')); ?>" class="brand-logo hide-on-med-and-down"><img src="img/logo-ccomp.png" alt=""></a>
            <a id="logo-container" href="<?php echo e(url('/')); ?>" class="brand-logo center hide-on-large-only"><img src="img/logo-ccomp.png" alt=""></a>
            <a href="#" data-activates="nav-mobile" class="button-collapse"><i class="material-icons" style="color: #3cb6d8;">menu</i></a>
            <ul class="right hide-on-med-and-down ">
                <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li><a href="<?php echo e(url('/faq')); ?>">FAQ</a></li>
                <?php if(Auth::check()): ?>
                    <li><a href="<?php echo e(url('/home')); ?>" class="btn waves-effect waves-light secondary-btn"><?php echo e(Auth::user()->tim); ?></a></li>
                <?php else: ?>
                    <li><a href="<?php echo e(url('/login')); ?>" class="btn waves-effect waves-light secondary-btn">Login</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>
</div>
<!-- end of navbar dekstop -->
<!-- navbar for mobile -->
<ul id="nav-mobile" class="side-nav">
    <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
    <li><a href="faq.html">FAQ</a></li>
    <?php if(Auth::check()): ?>
        <li><a href="<?php echo e(url('/home')); ?>" class="btn waves-effect waves-light secondary-btn"><?php echo e(Auth::user()->tim); ?></a></li>
    <?php else: ?>
        <li><a href="<?php echo e(url('/login')); ?>" class="btn waves-effect waves-light secondary-btn">Login</a></li>
    <?php endif; ?>
</ul>
<!-- end of navbar for mobile -->
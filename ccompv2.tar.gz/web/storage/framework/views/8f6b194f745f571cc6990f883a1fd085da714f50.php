<?php $__env->startSection('content'); ?>
<main>

    <div id="admin-team">
        <div class="container">
            <div class="row">
            	<div class="row center-align">
                    <a href="<?php echo e(url('admin/pengumuman/create')); ?>" class="btn-large-blue waves-effect waves-light">Tambah</a>
                </div>
                <table class="bordered striped highlight">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Lomba</th>
                            <th>Judul</th>
                            <th>Isi</th>
                            <th>Opsi</th>
                            <th>Dibuat</th>
                            <th>Diedit</th>
                        </tr>
                    </thead>

                    <tbody>
	                    <?php foreach($pengumuman as $list): ?>
	                        <tr>
	                            <td><?php echo e($list->id_peng); ?></td>
	                            <td><?php echo e($list->lomba); ?></td>
	                            <td><?php echo e($list->judul); ?></td>
	                            <td><?php echo e($list->isi); ?></td>
	                            <td><?php echo e($list->created_at); ?></td>
	                            <td><?php echo e($list->updated_at); ?></td>
	                            <td>
	                                <a href="<?php echo e(url('admin/pengumuman/'.$list->id_peng.'/edit')); ?>" class="tooltipped" data-position="top" data-delay="50" data-tooltip="Edit"><i class="zmdi zmdi-edit blue-text text-lighten-3"></i></a>
                                    <form action="<?php echo e(url('admin/pengumuman/'.$list->id_peng)); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('DELETE')); ?>

                                        <button type="submit" id="delete-task-<?php echo e($list->id_peng); ?>" class=" btn tooltipped" data-position="top" data-delay="50" data-tooltip="Hapus">
                                            <i class="zmdi zmdi-delete zmdi-hc-2x red-text text-lighten-1"></i>
                                    </button>
                                </form>
	                            </td>
	                        </tr>
	                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
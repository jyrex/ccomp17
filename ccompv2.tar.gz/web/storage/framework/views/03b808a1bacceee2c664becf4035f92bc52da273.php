<?php $__env->startSection('content'); ?>
<main>

    <div id="admin-peserta">
        <div class="container">
            <div class="row">
                <table class="bordered striped highlight">
                    <thead>
                        <tr>
                        	<th>ID</th>
                            <th>Tim</th>
                            <th>Bukti</th>
                            <th>Keterangan</th>
                        </tr>
                    </thead>

                    <tbody> 
                    <?php foreach($pembayaran as $list): ?>
                        <tr>
                        	<td><?php echo e($list->id_pembayaran); ?></td>
                            <td><?php echo e($list->tim->tim); ?></td>
                            <td><a href="<?php echo e(url('/'.$list->bukti)); ?>"><?php echo e($list->bukti); ?></a></td>
                            <td><?php echo e($list->keterangan); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
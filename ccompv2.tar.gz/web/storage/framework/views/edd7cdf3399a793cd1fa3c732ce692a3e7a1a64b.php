<?php $__env->startSection('content'); ?>
<main>

    <div id="admin-peserta">
        <div class="container">
            <div class="row">
                <table class="bordered striped highlight">
                    <thead>
                        <tr>
                        	<th>ID</th>
                            <th>NIM</th>
                            <th>Nama</th>
                            <th>Fakultas</th>
                            <th>Prodi</th>
                            <th>Opsi</th>
                        </tr>
                    </thead>

                    <tbody> 
                    <?php foreach($peserta as $list): ?>
                        <tr>
                        	<td><?php echo e($list->id); ?></td>
                            <td><?php echo e($list->NIM); ?></td>
                            <td><?php echo e($list->nama_lengkap); ?></td>
                            <td><?php echo e($list->prodi->fakultas->fakultas); ?></td>
                            <td><?php echo e($list->prodi->program_studi); ?></td>
                            <td>
                                <a href="<?php echo e(url('/team/'.$list->id.'/edit')); ?>" class="tooltipped" data-position="top" data-delay="50" data-tooltip="Edit"><i class="zmdi zmdi-edit blue-text text-lighten-3"></i></a>
                                <form action="<?php echo e(url('admin/peserta/'.$list->id)); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <button type="submit" id="delete-task-<?php echo e($list->id); ?>" class=" btn tooltipped" data-position="top" data-delay="50" data-tooltip="Hapus">
                                        <i class="zmdi zmdi-delete zmdi-hc-2x red-text text-lighten-1"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('addhead'); ?><link rel="stylesheet" href="<?php echo e(url('/stylesheets/admin.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main>
    <div id="admin-edit-peserta">
        <div class="container">
            <div class="row">
                <?php if(!isset($anggota)): ?>
                <div class="row center-align">
                    <a href="<?php echo e(url('/team/create')); ?>" class="btn-large-blue waves-effect waves-light">Masukkan data ketua</a>
                </div>
                <?php elseif($anggota->count() < 3): ?>
                <div class="row center-align">
                    <a href="<?php echo e(url('/tambah')); ?>" class="btn-large-blue waves-effect waves-light">Tambah anggota</a>
                </div>
                <?php endif; ?>
                <?php if(isset($anggota)): ?>
                    <?php foreach($anggota as $card): ?>
                        <div class="col l4">
                            <div class="card">
                                <div class="card-image">
                                    <img src="<?php echo e(url('/'.$card->peserta->ktm)); ?>" alt="Anda telah mengubah NIM anda, silahkan lapor admin">
                                </div>
                                <div class="card-content">
                                    <span class="card-title"><?php echo e(Auth::user()->tim); ?></span>
                                    <ul>
                                        <li><?php echo e($card->peserta->NIM); ?></li>
                                        <li><?php echo e($card->peserta->nama_lengkap); ?></li>
                                        <li><?php echo e($card->peserta->prodi->fakultas->fakultas); ?></li>
                                        <li><?php echo e($card->peserta->prodi->program_studi); ?></li>
                                    </ul>
                                </div>
                                <?php if(Auth::user()->role == "admin"): ?>
                                <div class="card-action">
                                    <a href="<?php echo e(url('/team/'.$card->peserta->id.'/nama')); ?>" class="tooltipped" data-position="top" data-delay="50" data-tooltip="Edit"><i class="zmdi zmdi-edit blue-text text-lighten-3"></i></a>
                                    <form action="<?php echo e(url('team/'.$card->id)); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('DELETE')); ?>

                                        <button type="submit" id="delete-task-<?php echo e($card->id); ?>" class=" btn tooltipped" data-position="top" data-delay="50" data-tooltip="Hapus">
                                            <i class="zmdi zmdi-delete zmdi-hc-2x red-text text-lighten-1"></i>
                                        </button>
                                    </form>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
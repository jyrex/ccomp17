<?php $__env->startSection('content'); ?>
<main>
    <div id="news">
        <div class="container">
            <div class="row">
                <div class="col l6">
                    <div class="card">
                        <div class="card-image">
                            <img src="http://materializecss.com/images/sample-1.jpg">
                            <span class="date">10 juni 2017</span>
                        </div>
                        <div class="card-content">
                            <span class="card-title">Card Title</span>
                            <p>I am a very simple card. I am good at containing small bits of information. I am convenient because I require little markup to use effectively.</p>
                        </div>
                        <div class="card-action">
                            <a href="#">This is a link</a>
                        </div>
                    </div>
                </div>
                <div class="col l6">
                    <div class="card">
                        <div class="card-image">
                            <img src="http://materializecss.com/images/sample-1.jpg">
                            <span class="date">10 juni 2017</span>
                        </div>
                        <div class="card-content">
                            <span class="card-title">Card Title</span>
                            <p>I am a very simple card. I am good at containing small bits of information. I am convenient because I require little markup to use effectively.</p>
                        </div>
                        <div class="card-action">
                            <a href="#">This is a link</a>
                        </div>
                    </div>
                </div>
                <div class="col l6">
                    <div class="card">
                        <div class="card-image">
                            <img src="http://materializecss.com/images/sample-1.jpg">
                            <span class="date">10 juni 2017</span>
                        </div>
                        <div class="card-content">
                            <span class="card-title">Card Title</span>
                            <p>I am a very simple card. I am good at containing small bits of information. I am convenient because I require little markup to use effectively.</p>
                        </div>
                        <div class="card-action">
                            <a href="#">This is a link</a>
                        </div>
                    </div>
                </div>
                <div class="col l6">
                    <div class="card">
                        <div class="card-image">
                            <img src="http://materializecss.com/images/sample-1.jpg">
                            <span class="date">10 juni 2017</span>
                        </div>
                        <div class="card-content">
                            <span class="card-title">Card Title</span>
                            <p>I am a very simple card. I am good at containing small bits of information. I am convenient because I require little markup to use effectively.</p>
                        </div>
                        <div class="card-action">
                            <a href="#">This is a link</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
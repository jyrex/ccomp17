<!-- JavaScripts -->
<script
  src="https://code.jquery.com/jquery-3.2.0.min.js"
  integrity="sha256-JAW99MJVpJBGcbzEuXk4Az05s/XyDdBomFqNlM3ic+I="
  crossorigin="anonymous"></script>

<script src="<?php echo e(asset('js/materialize.js')); ?>"></script>
<script src="<?php echo e(asset('js/init.js')); ?>"></script>

<?php echo $__env->yieldContent('page-script'); ?>
<?php $__env->startSection('title'); ?>
Login C-Compiler 2017
<?php $__env->stopSection(); ?>

<?php $__env->startSection('addhead'); ?>
<link href="<?php echo e(url('/stylesheets/style.css')); ?>" type="text/css" rel="stylesheet" media="screen,projection" />
<style type="text/css">
    .navbar-fixed {
        display: none;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="main">
    <div class="main-content">
        <center>
            <a href="<?php echo e(url('/')); ?>" class="brand-logo"><img src="<?php echo e(url('img/logowhite.png')); ?>" alt="" class="logo"></a>
            <div class="card">
                <!--title-->
                <div class="card-content black-text"> <span class="card-title flow-text">LOGIN</span>
                    <p class="fow-text">Have An Account?</p>
                </div>
                <!--end of title-->
                <div class="garis"></div>
                <!--form login-->
                <form action="<?php echo e(url('/login')); ?>" method="POST" class="kanantext">
                <?php echo e(csrf_field()); ?>

                    <div class="row">
                        <div class="input-field col s12">Nama Tim
                            <input name="tim" id="tim" type="text" class="validate">
                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s12">Password
                            <input name="password" id="password" type="password" class="validate">
                        </div>
                    </div>
                    <div class="row center">
                            <button class="btn-large-blue waves-effect waves-light" type="submit" style="width: 90%;">Login</button>
                        </div>
                </form>
                <!--end of form login-->
                <!--card action and button-->
                <div class="card-action center">
                    <!-- <span>Lupa password? <a href="<?php echo e(url('/password/reset')); ?>">Klik disini</a>! <br>  -->
                    Belum punya akun? <a href="<?php echo e(url('register')); ?>">Register</a>! / kembali ke <br> 
                    <a href="<?php echo e(url('/')); ?>"> halaman utama</a>?</span>
                   <!--  <a href="makeaccount.html" class="indigo-text">Sign Up</a>
                    <a href="" class="indigo-text">Login</a> -->
                </div>
                <!--end of card action and button-->
            </div>
        </center>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
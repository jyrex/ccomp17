<?php $__env->startSection('content'); ?>
<main>

    <div id="admin-peserta">
        <div class="container">
            <div class="row">
                <table class="bordered striped highlight">
                    <thead>
                        <tr>
                        	<th>No</th>
                            <th>Nama Tim</th>
                            <th>Lomba Diikuti</th>
                            <th>Email Ketua</th>
                            <th>NIM Ketua</th>
                            <th>HP Ketua</th>
                            <th>Submission</th>
                        </tr>
                    </thead>

                    <tbody> 
                    <?php foreach($tim as $list): ?>
                        <tr>
                        	<td><?php echo e($list->id); ?></td>
                            <td><?php echo e($list->tim); ?></td>
                            <td><?php echo e($list->lomba); ?></td>
                            <td><?php echo e($list->email); ?></td>
                            <td><?php echo e($list->id_ketua); ?></td>
                            <td><?php echo e($list->hp); ?></td>
                            <td><?php echo e($list->submission); ?></td>
                            <td>
                                <a href="" class="tooltipped" data-position="top" data-delay="50" data-tooltip="Edit"><i class="zmdi zmdi-edit zmdi-hc-2x blue-text text-lighten-3"></i></a>
                                <form action="<?php echo e(url('admin/tim/'.$list->id)); ?>" method="POST">
						            <?php echo e(csrf_field()); ?>

						            <?php echo e(method_field('DELETE')); ?>

						            <button type="submit" id="delete-task-<?php echo e($list->id); ?>" class=" btn tooltipped" data-position="top" data-delay="50" data-tooltip="Hapus">
						            	<i class="zmdi zmdi-delete zmdi-hc-2x red-text text-lighten-1"></i>
						            </button>
						        </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
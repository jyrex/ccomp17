<?php $__env->startSection('content'); ?>
<div id="register">
    <div class="container">
        <div class="card-panel">
            <div class="row">
                <div class="col l10 offset-l1 ">
                    <h5 style="color: #73d6e7;"><strong>Pendaftaran C-Compiler UGM 2017</strong></h5>
                </div>

                <!-- tim form -->
                <div class="col l5 offset-l1 s12">
                    <div class="row">
                        <form class="col s12" role="form" method="POST" action="<?php echo e(url('/register')); ?>">
                        <?php echo csrf_field(); ?>

                            <!-- title tim -->
                            <div class="row">
                                <div class="col s12">
                                    <p><strong>Tim</strong></p>
                                </div>
                            </div>
                            <!-- end of title tim -->
                            <!-- nama tim -->
                            <div class="row<?php echo e($errors->has('tim') ? ' has-error' : ''); ?>">
                                <div class="input-field col s12">
                                    <input name="tim" id="tim" type="text" class="validate" value="<?php echo e(old('tim')); ?>">
                                    <label for="tim">Nama Tim</label>
                                </div>
                            </div>
                            <!-- end of nama tim -->
                            <!-- kategori lomba -->
                            <div class="row">
                                <div class="input-field col s12">
                                    <select>
                                        <option value="" disabled selected>Choose your option</option>
                                        <option value="CP">Competitive Programming</option>
                                        <option value="Data Mining">Data Mining</option>
                                        <option value="Software Dev">Software Dev</option>
                                        <option value="UI/UX">UI/UX</option>
                                        <option value="Embedded System">Embedded System</option>
                                        <option value="Line Follower">Line Follower</option>
                                    </select>
                                    <label>Kategori Lomba</label>
                                </div>
                                <!-- end of kategori lomba -->
                            </div>
                            <!-- alamat email -->
                            <div class="row<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                <div class="input-field col s12">
                                    <input id="email" type="email" class="validate" value="<?php echo e(old('email')); ?>">
                                    <label for="email">Alamat Email</label>
                                </div>
                            </div>
                            <!-- end of alamat email -->
                            <!-- password -->
                            <div class="row<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                <div class="input-field col s12">
                                    <input id="password" type="password" class="validate">
                                    <label for="password">Password</label>
                                </div>
                            </div>
                            <!-- end of password -->
                            <input type="submit" class="btn waves-effect waves-light secondary-btn right" href="registerlg.html"></input>
                            <!-- end of button next -->
                        </form>
                    </div>
                </div>
			</div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
(function ($) {
    $(function () {

        $('.button-collapse').sideNav();
        $('.parallax').parallax();
        $('.collapsible').collapsible();
        $('select').material_select();
         $('.modal').modal();


    }); // end of document ready
})(jQuery); // end of jQuery name space